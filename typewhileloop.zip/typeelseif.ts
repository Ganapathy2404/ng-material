var  num:number = 5
if (num > 0) { 
   console.log("number is positive") 
}